package demos.gui.uicomponents;

import io.datafx.controller.ViewController;

@ViewController(value = "/fxml/ui/Slider.fxml", title = "Material Design Example")
public class SliderController {

}
